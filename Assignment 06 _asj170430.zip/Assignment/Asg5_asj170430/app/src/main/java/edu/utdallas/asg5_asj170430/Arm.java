/********************************************************************************************
 *  Rectangular canvas arm
 * *******************************************************************************************/
package edu.utdallas.asg5_asj170430;
import android.graphics.RectF;
/**
 * Created by aadis on 27-11-2018.
 */

public class Arm {

    /********************************************************************************************
     *  Var declaration.
     * *******************************************************************************************/
    private RectF ArmRect;
    private float length;
    private float height;
    private float armSpeed;
    public final int isStopped = 0;
    public final int isLeft = 1;
    public final int isRight = 2;
    private int isArmRotating = 0;
    private float x;
    private float y;

    /********************************************************************************************
     *  Arm constructor.
     * *******************************************************************************************/
    public Arm(int screenX,int screenY){
        length = 130;
        height = 20;
        x = screenX / 2;
        y = screenY - 20;
        ArmRect = new RectF(x,y,x+length,y+height);
        armSpeed = 350;
    }

    /********************************************************************************************
     *  Update functionality for arm.
     *  if left is pressed, arm should move left.
     *  if right is pressed, arm should move right.
     * *******************************************************************************************/
    public void update(long fps){
        if(isArmRotating == isLeft){
            x = x - armSpeed / fps;
        }
        if(isArmRotating == isRight){
            x = x + armSpeed /fps;
        }
        ArmRect.left = x;
        ArmRect.right = x + length;
    }

    /********************************************************************************************
     *  return arm.
     * *******************************************************************************************/
    public RectF getArm(){
        return ArmRect;
    }

    /********************************************************************************************
     *  if left, left should be set.
     *  if right, right should be set.
     * *******************************************************************************************/
    public void setRotateState(int state){
        isArmRotating = state;
    }

}
