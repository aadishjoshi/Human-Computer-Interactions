/********************************************************************************************
 *  Rectangular canvas Ball for 10x 10 px.
 * *******************************************************************************************/
package edu.utdallas.asg5_asj170430;

import android.graphics.RectF;

import java.util.Random;
/**
 * Created by aadis on 27-11-2018.
 */

public class Ball {

    /********************************************************************************************
     *  variable declaration.
     * *******************************************************************************************/
    RectF rectangle;
    float xSpeed;
    float ySpeed;
    float ballWidth = 10;
    float ballHeight = 10;

    /********************************************************************************************
     *  Ball constructor for 10x10px.
     * *******************************************************************************************/
    public Ball(int screenX, int screenY){
        xSpeed = 200;
        ySpeed = -400;
        rectangle = new RectF();
    }
    /********************************************************************************************
     *  Rectangular canvas arm
     * *******************************************************************************************/
    public RectF getRectangle(){
        return rectangle;
    }

    /********************************************************************************************
     *  Opposite X and Y direction when obstacles are hit.
     * *******************************************************************************************/
    public void oppYDirection(){
        ySpeed = -ySpeed;
    }

    public void oppXDirection(){
        xSpeed = -xSpeed;
    }

    /********************************************************************************************
     *  Update ball speed based on frames per seconds.
     * *******************************************************************************************/
    public void update(long fps){
        rectangle.left = rectangle.left + (xSpeed / fps);
        rectangle.top = rectangle.top + (ySpeed / fps);
        rectangle.right = rectangle.left + ballWidth;
        rectangle.bottom = rectangle.top - ballHeight;
    }

    /********************************************************************************************
     *  Ball direction set randomly.
     * *******************************************************************************************/
    public void defaultRandomSpeed(){
        Random r = new Random();
        int ans = r.nextInt(2);
        if(ans == 0){
            oppXDirection();
        }
    }

    /********************************************************************************************
     *  Avoiding obstacles in X and Y direction
     * *******************************************************************************************/
    public void avoidObstacleY(float y){
        rectangle.bottom = y;
        rectangle.top = y - ballHeight;
    }

    public void avoidObstacleX(float x){
        rectangle.left = x;
        rectangle.right = x+ballWidth;
    }

    /********************************************************************************************
     *  Ball reset to middle of the screen
     * *******************************************************************************************/
    public void reset(int x,int y){
        rectangle.left = x/2;
        rectangle.top = y - 20;
        rectangle.right = x/2 + ballWidth;
        rectangle.bottom = y - 20 - ballHeight;
    }

}
