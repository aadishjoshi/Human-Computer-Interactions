package edu.utdallas.asg5_asj170430;

/**
 * Created by aadis on 04-11-2018.
 */

public class ListSavedData {
    String playerName;
    int score;
    String date;

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
