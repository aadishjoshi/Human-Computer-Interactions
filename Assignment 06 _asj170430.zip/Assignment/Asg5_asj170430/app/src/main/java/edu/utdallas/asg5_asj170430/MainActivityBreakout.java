/*
* Breakout game:Bounce a ball off a paddle to break bricks at the top of the screen.
* Question Task:
* Your assignment is to write a relatively simple game, a variation on a popular Atari game called Breakout.
* It works like this: Bounce a ball off a paddle to break bricks at the top of the screen.  The score could be the time it takes to break all of the bricks, or you could be scored on how many bricks you break before losing three lives. (
* Losing a life means missing the ball with the paddle.).
*
* MainActivity for breakout gaming:
* Written by :-
* Name: Aadish Joshi
* UTDID: asj170430
* Contact: aadish.joshi@utdallas.edu
* Date: November 27, 2018.
* */

package edu.utdallas.asg5_asj170430;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


public class MainActivityBreakout extends AppCompatActivity {

    supportViewClass supportView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportView = new supportViewClass(this);
        setContentView(supportView);

    }

    @Override
    protected void onResume() {
        super.onResume();
        supportView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        supportView.pause();
    }

    /*-------------------------------------------------------------*/

    /********************************************************************************************
     *  SupportViewClass is a inline class
     * This will be set to setContentView of the main activity
     * *******************************************************************************************/

    public class supportViewClass extends SurfaceView implements  Runnable {


        /********************************************************************************************
         *  declaration of the variables
         * *******************************************************************************************/

        Thread playThread = null;
        SurfaceHolder playHolder;
        Canvas canvas;
        Paint paint;
        Arm arm;
        Ball ball;
        Brick[] bricks = new Brick[200];

        int screenX;
        int screenY;
        int noBricks = 0;
        int score = 0;
        int lives = 3;

        boolean isPaused = true;
        long fps;
        boolean saved = false;
        private long currentTimeFrame;
        volatile boolean isPlaying;

        /********************************************************************************************
         *  Class constructor
         *  If the ball hits the bottom of the screen, lives are deducted.
         *  Maximum lives 3 are allowed. if gone below 3, then reset is called.
         * *******************************************************************************************/
        public supportViewClass(Context context){
            super(context);
            playHolder = getHolder();
            paint = new Paint();

            Display myDisplay = getWindowManager().getDefaultDisplay();

            Point getSize = new Point();
            myDisplay.getSize(getSize);

            screenX = getSize.x;
            screenY = getSize.y;

            arm = new Arm(screenX,screenY);
            ball = new Ball(screenX,screenY);

            BricksAndReset();
        }

        /********************************************************************************************
         *  Reset functionality
         *  bricks are restored but the life is deducted by 1 every time
         * *******************************************************************************************/
        public void BricksAndReset(){
            ball.reset(screenX,screenY);
            int brickWidth = screenX / 8;
            int brickHeight = screenY / 10;

            noBricks = 0;

            for(int col = 0; col <8;col++){
                for(int row = 0; row<3;row++){
                    bricks[noBricks] = new Brick(row,col,brickWidth,brickHeight);
                    noBricks++;
                }
            }

            if(lives == 0){
                saved = true;
//                score = 0;
//                lives = 3;
            }
        }

        /********************************************************************************************
         *  Overrided run method for implemented Runnable interface.
         *  frames per seconds are set.
         * *******************************************************************************************/
        @Override
        public void run() {
            while(isPlaying){
                long begingFTime = System.currentTimeMillis();
                if(!isPaused){
                    update();
                }
                draw();
                currentTimeFrame = System.currentTimeMillis() - begingFTime;
                if(currentTimeFrame >= 1){
                    fps = 1000/currentTimeFrame;
                }
            }

        }

        /********************************************************************************************
         *  Overrided OnTouchEvent listener.
         *  arm rotations are set.
         * *******************************************************************************************/
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch(event.getAction() & MotionEvent.ACTION_MASK){
                case MotionEvent.ACTION_DOWN:
                    isPaused  = false;

                    if(event.getX() > screenX / 2){
                        arm.setRotateState(arm.isRight);
                    }else{
                        arm.setRotateState(arm.isLeft);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    arm.setRotateState(arm.isStopped);
                    break;
            }
            return true;
        }


        /********************************************************************************************
         *  Draw method drawing canvas.
         *  if number of bricks equals points scored, person is declared as a winner.
         *  If lives deduct to zero, you lose the game.
         * *******************************************************************************************/
        public void draw(){
            if(playHolder.getSurface().isValid()){

                canvas = playHolder.lockCanvas();
                canvas.drawColor(Color.argb(255,0,0,0));
                paint.setColor(Color.argb(255,255,255,255));
                canvas.drawRect(arm.getArm(),paint);
                canvas.drawRect(ball.getRectangle(),paint);
                paint.setColor(Color.argb(255,249,129,0));

                for(int i =0; i< noBricks; i++){
                    if(bricks[i].getVisibileStatus()){
                        canvas.drawRect(bricks[i].getRectangle(), paint);
                    }
                }

                paint.setColor(Color.argb(255,255,255,255));

                paint.setTextSize(40);
                canvas.drawText("Score: "+ score + " Lives:" + lives, 10,50,paint);

                if(score == noBricks *10){
                    paint.setTextSize(90);
                    canvas.drawColor(Color.TRANSPARENT);
                    canvas.drawText("You Won!",10,screenY/2,paint);
                }

                if(lives <= 0){
                    paint.setTextSize(90);
                    canvas.drawColor(Color.TRANSPARENT);
                    canvas.drawText("You Lost!",10,screenY/2,paint);
                    try{
                        Thread.sleep(3000);
                        Intent i = new Intent(MainActivityBreakout.this, AddData.class);
                        i.putExtra("score",""+score);
                        startActivity(i);
                    }catch(Exception e){
                        Log.e("Error!","Error in thread");
                    }

                }


                playHolder.unlockCanvasAndPost(canvas);
            }
        }

        /********************************************************************************************
         *  Update method for calculating functionalities.
         * *******************************************************************************************/
        public void update(){

            arm.update(fps);
            ball.update(fps);

            //if ball hits the brick, brick should be invisible and score should be increased by 10.
            for(int i=0;i <noBricks; i++){
                if(bricks[i].getVisibileStatus()){
                    if(RectF.intersects(bricks[i].getRectangle(), ball.getRectangle())){
                        bricks[i].setInvisible();
                        ball.oppYDirection();
                        score = score +10;
                    }
                }
            }

            //if ball hits the brick, it should reverse back to arm.
            if(RectF.intersects(arm.getArm(),ball.getRectangle())){
                ball.defaultRandomSpeed();
                ball.oppYDirection();
                ball.avoidObstacleY(arm.getArm().top - 2);
            }

            //if ball hits the bottom, it should reverse back up and 1 life is deducted.
            if(ball.getRectangle().bottom > screenY){
                ball.oppYDirection();
                ball.avoidObstacleY(screenY - 2);
                lives --;
                if(lives == 0){
                    isPaused = true;
                    BricksAndReset();
                }
            }

            //if hit the top, ball should reverse.
            if(ball.getRectangle().top < 0){
                ball.oppYDirection();
                ball.avoidObstacleY(12);
            }

            //if ball hits the left wall, it should reverse
            if(ball.getRectangle().left < 0){
                ball.oppXDirection();
                ball.avoidObstacleX(2);

            }

            // if a ball hits the right ball, it should reverse.
            if(ball.getRectangle().right > screenX - 10){
                ball.oppXDirection();
                ball.avoidObstacleX(screenX - 22);
            }

            //if all bricks are invisible, you win.
            if(score == noBricks *10){
                isPaused = true;
                BricksAndReset();
            }
        }

        /********************************************************************************************
         *  Thread pause functionality
         * *******************************************************************************************/
        public void pause(){
            isPlaying = false;
            try{
                playThread.join();
            }catch(Exception e){
                Log.e("Error:","e");
            }
        }
        /********************************************************************************************
         *  Thread resume functionality.
         * *******************************************************************************************/
        public void resume(){
            isPlaying = true;
            playThread = new Thread(this);
            playThread.start();
        }

    }














}
